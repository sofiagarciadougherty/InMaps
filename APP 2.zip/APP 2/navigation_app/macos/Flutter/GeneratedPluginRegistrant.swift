//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import reactive_ble_mobile

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ReactiveBlePlugin.register(with: registry.registrar(forPlugin: "ReactiveBlePlugin"))
}
