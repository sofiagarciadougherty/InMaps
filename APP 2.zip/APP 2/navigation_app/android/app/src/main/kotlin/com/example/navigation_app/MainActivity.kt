package com.example.navigation_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
